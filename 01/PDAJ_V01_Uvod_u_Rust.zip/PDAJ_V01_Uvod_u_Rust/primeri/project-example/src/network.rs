// This file defines the "network" module and its sub-module "server".
// It is a file module (src/network.rs). Its sub-module "server" is defined inline, so no extra file is needed.

// Public function in the "network" module
pub fn connect() {
    println!("Connecting to the network...");
}

// Inline sub-module: the body is written in place (curly brackets instead of a semicolon)
pub mod server {
    use crate::utils::helper; // Absolute path from the crate root: "utils" is in the same crate (library), so we start with crate::

    // A function in the "server" module
    pub fn start_server() {
        println!("Server started from the network::server module!");
        // Call a function from another module of the same crate
        helper::print_help();
    }
}
