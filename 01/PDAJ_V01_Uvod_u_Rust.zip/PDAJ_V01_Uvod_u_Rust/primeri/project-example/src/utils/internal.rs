// Private module: utils/mod.rs declares it with `mod internal;` (no pub).
// The function is pub, but it is still not reachable outside the library, because the module is not pub.
pub fn decorate(text: &str) -> String {
    "** ".to_string() + text + " **"
}
