// This file defines the "utils" module and its sub-modules "helper" and "internal".

pub mod helper; // Public sub-module: the compiler looks for it in src/utils/helper.rs
mod internal; // Private sub-module (no pub): visible only in utils and its descendants

// Public function of the "utils" module; it may use the private module because it is in the same module
pub fn print_hello() {
    println!("{}", internal::decorate("Hello from the utils module!"));
}
