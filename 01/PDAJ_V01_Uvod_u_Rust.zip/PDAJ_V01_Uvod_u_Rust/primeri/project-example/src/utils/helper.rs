use crate::network; // Absolute path from the crate root: "network" is a sibling of "utils" in the same crate (library).

// A helper function within the "helper" module
pub fn print_help() {
    // "internal" is private, but helper may use it: a private module is visible in its parent (utils)
    // and in all of the parent's descendants, including this sibling module
    println!("{}", super::internal::decorate("Helper function from the utils::helper module!"));
    // Call a function from another module of the same crate
    network::connect();
}
