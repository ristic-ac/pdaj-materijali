// A module can be defined in three ways: as src/<name>.rs, as src/<name>/mod.rs, or inline.
// Having both src/<name>.rs and src/<name>/mod.rs is an error.
pub mod network; // File module: here it is src/network.rs (the 2018 style; its sub-module is inline)
pub mod utils; // File module: here it is src/utils/mod.rs (the older style)

// Inline module: the body is written in place (curly brackets instead of a semicolon), no extra file
pub mod config {
    pub fn print_config() {
        println!("Config module defined inline in lib.rs.");
    }
}

// Removing `pub` would make a module private to the crate and inaccessible from outside, which in
// turn means the main binary crate would not be able to use it, i.e., it would cause compilation errors in `src/main.rs`.
