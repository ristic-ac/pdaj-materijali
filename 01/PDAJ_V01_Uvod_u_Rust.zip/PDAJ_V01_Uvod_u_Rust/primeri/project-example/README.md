# project-example

Jedan paket sa bibliotečkim crate-om (`project_example`, `src/lib.rs`) i nekoliko binarnih crate-ova koji ga koriste.

## Pokretanje

Komande se pokreću iz ovog foldera (`project-example/`).

Kompajliranje biblioteke i svih binarnih crate-ova:

```bash
cargo build
```

Pokretanje svakog binarnog crate-a:

```bash
cargo run --bin main
cargo run --bin binary1
cargo run --bin binary2
cargo run --bin visibility
```

## Namerna greška kompajlera

Binarni crate `nocompile_private_module` se namerno ne kompajlira: koristi privatni modul `utils::internal`.
`cargo build` ga preskače; gradi se samo uz feature `nocompile`, i tada se vidi greška:

```bash
cargo build --features nocompile --bin nocompile_private_module
```

Očekivano: ``error[E0603]: module `internal` is private``
