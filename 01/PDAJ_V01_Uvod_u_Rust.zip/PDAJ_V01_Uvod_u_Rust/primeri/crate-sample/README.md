# crate-sample

Paket `crate-sample-pdaj` sa bibliotečkim crate-om (`crate_sample`, `src/lib.rs`) i binarnim crate-om koji ga koristi (`src/main.rs`).
Biblioteka ima dokumentacione komentare (`///`) sa primerima koji se izvršavaju kao testovi.

## Pokretanje

Komande se pokreću iz ovog foldera (`crate-sample/`).

Kompajliranje biblioteke i binarnog crate-a:

```bash
cargo build
```

Pokretanje binarnog crate-a:

```bash
cargo run --bin crate-sample-pdaj
```

## Testovi iz dokumentacije

Primeri iz `///` komentara se izvršavaju kao testovi:

```bash
cargo test --doc
```

## Dokumentacija

Generisanje dokumentacije i otvaranje u pregledaču:

```bash
cargo doc --open
```

Bez `--open` dokumentacija se samo generiše, u `target/doc/crate_sample/index.html` u folderu iznad ovog (zajednički `target/` workspace-a).

## Namerna greška kompajlera

Binarni crate `nocompile_features` se namerno ne kompajlira. `cargo build` ga preskače; gradi se samo uz feature `nocompile`, i tada se vidi greška:

```bash
cargo build --features nocompile --bin nocompile_features
```

Očekivano: `error[E0308]: mismatched types`
