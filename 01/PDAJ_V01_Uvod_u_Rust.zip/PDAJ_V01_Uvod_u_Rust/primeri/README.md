# Workspace sa primerima

Workspace sa dva paketa: `crate-sample/` (paket `crate-sample-pdaj`) i `project-example/`.
Paketi dele jedan `Cargo.lock` i jedan `target/` u ovom folderu. Uputstvo za svaki paket je u njegovom `README.md`.

## Pokretanje

Komande se pokreću iz ovog foldera (koren workspace-a).

Kompajliranje svih paketa:

```bash
cargo build
```

Kompajliranje jednog paketa (`-p` je ime paketa iz njegovog `Cargo.toml`):

```bash
cargo build -p project-example
cargo build -p crate-sample-pdaj
```

Pokretanje binarnog crate-a iz određenog paketa:

```bash
cargo run -p project-example --bin main
cargo run -p crate-sample-pdaj --bin crate-sample-pdaj
```

Svi testovi (i testovi iz dokumentacije) u svim paketima:

```bash
cargo test
```

Optimizovan build (profil `release` iz `Cargo.toml` ovog foldera):

```bash
cargo build --release
```

## Namerne greške kompajlera

Feature `nocompile` uključuje primere koji se namerno ne kompajliraju, za svaki paket posebno:

```bash
cargo build -p project-example --features nocompile
cargo build -p crate-sample-pdaj --features nocompile
```

Očekivano: ``error[E0603]: module `internal` is private``, odnosno `error[E0308]: mismatched types`
