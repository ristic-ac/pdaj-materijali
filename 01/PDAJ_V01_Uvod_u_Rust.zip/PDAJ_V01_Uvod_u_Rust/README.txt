Uvod u Rust
Paralelne i distribuirane arhitekture i jezici

Sadržaj:
  PDAJ_V01_Uvod_u_Rust.html  slajdovi (otvoriti u pregledaču)
  PDAJ_V01_Uvod_u_Rust.pdf   isti sadržaj za štampu
  primeri/  cargo projekat sa primerima sa slajdova

Uputstvo za pokretanje primera: primeri/README.md

Projekat je proveren na Rust 1.75.0 i na najnovijoj stabilnoj verziji.
