Vlasništvo
Paralelne i distribuirane arhitekture i jezici

Sadržaj:
  PDAJ_V03_Vlasnistvo.html  slajdovi (otvoriti u pregledaču)
  PDAJ_V03_Vlasnistvo.pdf   isti sadržaj za štampu
  primeri/  cargo projekat sa primerima sa slajdova

Pokretanje primera (iz foldera primeri/):
  cargo run --bin <primer>
Primeri čije ime počinje sa nocompile_ se namerno ne kompajliraju. Grešku
kompajlera prikazuje: cargo build --features nocompile --bin <primer>

Primeri:
  borrow, dangling, hashmap, iterations, iterations_tuples, manual_str, move_into_function, move_return_values, move_tuple_return, mut_parameter, mut_reference_pass_twice, nocompile_move, nocompile_move_from_vec, nocompile_mut_borrow_immutable, nocompile_mut_reference_move, nocompile_mut_twice, nocompile_shared_and_mut, nocompile_slice_then_clear, nocompile_tuple, reference_mutability, references_bindings, references_deref, references_reassign, references_reborrow, references_shared_then_mut, slices, str_slice, str_slice_utf8, strings, strings_clone, strings_move, vector

Projekat je proveren na Rust 1.75.0 i na najnovijoj stabilnoj verziji.
