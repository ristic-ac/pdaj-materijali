Zatvorenja, iteratori, pametni pokazivači
Paralelne i distribuirane arhitekture i jezici

Sadržaj:
  PDAJ_V06_Zatvorenja_iteratori_pametni_pokazivaci.html  slajdovi (otvoriti u pregledaču)
  PDAJ_V06_Zatvorenja_iteratori_pametni_pokazivaci.pdf   isti sadržaj za štampu
  primeri/  cargo projekat sa primerima sa slajdova

Pokretanje primera (iz foldera primeri/):
  cargo run --bin <primer>
Primeri čije ime počinje sa nocompile_ se namerno ne kompajliraju. Grešku
kompajlera prikazuje: cargo build --features nocompile --bin <primer>

Primeri:
  box_basic, box_heap_copy, closure_as_parameter, closure_capture_borrow, closure_capture_borrow_mut, closure_capture_move, closure_fn, closure_fn_mut, closure_fn_once, closure_fnonce_clone, closure_fnonce_reference, closure_lifetimes_fixes, closure_parameters_capture, cons, cow_into_owned_borrowed, cow_into_owned_owned, cow_to_mut_borrowed, cow_to_mut_owned, deref_coercion, drop, enum_size, iterator, iterator_chain, iterator_impl, iterator_lazy, iterator_ops, iterator_usage, my_box, nocompile_closure_fnonce, nocompile_closure_lifetimes, nocompile_closure_strictness, nocompile_cons, nocompile_rc_a, rc_b, rc_cycle, rc_refcell_tree, ref, refcell_borrow_panic, refcell_interior, unwrap_or_else, weak_no_cycle

Projekat je proveren na Rust 1.75.0 i na najnovijoj stabilnoj verziji.
