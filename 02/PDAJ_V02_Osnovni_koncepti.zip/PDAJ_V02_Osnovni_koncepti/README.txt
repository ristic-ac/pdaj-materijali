Osnovni koncepti
Paralelne i distribuirane arhitekture i jezici

Sadržaj:
  PDAJ_V02_Osnovni_koncepti.html  slajdovi (otvoriti u pregledaču)
  PDAJ_V02_Osnovni_koncepti.pdf   isti sadržaj za štampu
  primeri/  cargo projekat sa primerima sa slajdova

Pokretanje primera (iz foldera primeri/):
  cargo run --bin <primer>
Primeri čije ime počinje sa nocompile_ se namerno ne kompajliraju. Grešku
kompajlera prikazuje: cargo build --features nocompile --bin <primer>

Primeri:
  array, array_traits, casting_as, casting_from_into, constants, expressions, for, formatting, functions, hashmap, if, loop, match, numbers, shadowing, standard, stdin, stdin_index, string_parse, tuple, variables, vector, while

Projekat je proveren na Rust 1.75.0 i na najnovijoj stabilnoj verziji.
