Kolekcije, šabloni, argumenti komandne linije, rukovanje datotekama
Paralelne i distribuirane arhitekture i jezici

Sadržaj:
  PDAJ_V07_Kolekcije_sabloni_argumenti_komandne_linije_rukovanje_datotekama.html  slajdovi (otvoriti u pregledaču)
  PDAJ_V07_Kolekcije_sabloni_argumenti_komandne_linije_rukovanje_datotekama.pdf   isti sadržaj za štampu
  primeri/  cargo projekat sa primerima sa slajdova

Pokretanje primera (iz foldera primeri/):
  cargo run --bin <primer>
Primeri čije ime počinje sa nocompile_ se namerno ne kompajliraju. Grešku
kompajlera prikazuje: cargo build --features nocompile --bin <primer>

Primeri:
  args_basics, btreemap_basics, env_var, file_write_read, hashmap_access, hashmap_grouping, hashmap_median_mode, hashmap_update, hashset_basics, minigrep, nocompile_hashmap_ownership, nocompile_vector, patterns_destructuring, patterns_irrefutable, patterns_let_else, patterns_refutable, patterns_slices, patterns_usage, vector_basics, vector_enum_cells, vector_iteration, vector_methods

Projekat je proveren na Rust 1.75.0 i na najnovijoj stabilnoj verziji.
