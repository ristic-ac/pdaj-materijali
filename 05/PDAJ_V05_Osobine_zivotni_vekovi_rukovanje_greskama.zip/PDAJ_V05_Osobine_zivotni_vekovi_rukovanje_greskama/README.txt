Osobine, životni vekovi, rukovanje greškama
Paralelne i distribuirane arhitekture i jezici

Sadržaj:
  PDAJ_V05_Osobine_zivotni_vekovi_rukovanje_greskama.html  slajdovi (otvoriti u pregledaču)
  PDAJ_V05_Osobine_zivotni_vekovi_rukovanje_greskama.pdf   isti sadržaj za štampu
  primeri/  cargo projekat sa primerima sa slajdova

Pokretanje primera (iz foldera primeri/):
  cargo run --bin <primer>
Primeri čije ime počinje sa nocompile_ se namerno ne kompajliraju. Grešku
kompajlera prikazuje: cargo build --features nocompile --bin <primer>

Primeri:
  blanket, cond_impl, default, elision_functions, elision_methods, error, error_from, error_matching, expect, function_b, generics, lifetime_b, lifetime_lexer, lifetime_mut_self, lifetime_outlives, lifetime_struct, lifetime_text_and_borrow, lifetime_two_fields, lifetime_two_params, nocompile_function_a, nocompile_function_c, nocompile_lifetime_a, nocompile_lifetime_lexer, nocompile_lifetime_struct, nocompile_lifetime_text_and_borrow, nocompile_lifetime_two_fields, nocompile_propagate_d, nocompile_return_either, nocompile_set_part_from, nocompile_set_part_short_lived, nocompile_static, nocompile_static_bound, option, option_to_result, panic, parameters, propagate_a, propagate_b, propagate_c, propagate_main, result_to_option, return_val, static, traits, unwrap_a, unwrap_b, unwrap_or

Projekat je proveren na Rust 1.75.0 i na najnovijoj stabilnoj verziji.
