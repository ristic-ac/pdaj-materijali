Strukture i enumeracije
Paralelne i distribuirane arhitekture i jezici

Sadržaj:
  PDAJ_V04_Strukture_i_enumeracije.html  slajdovi (otvoriti u pregledaču)
  PDAJ_V04_Strukture_i_enumeracije.pdf   isti sadržaj za štampu
  primeri/  cargo projekat sa primerima sa slajdova

Pokretanje primera (iz foldera primeri/):
  cargo run --bin <primer>
Primeri čije ime počinje sa nocompile_ se namerno ne kompajliraju. Grešku
kompajlera prikazuje: cargo build --features nocompile --bin <primer>

Primeri:
  enum, enum_copy, enum_multiple, enum_tuple, generic_enums, generic_func, generic_intro, generic_struct, generic_struct_mixup, generic_struct_two_types, if_let, match_arms, match_exhaustive, methods, nocompile_match_exhaustive, nocompile_match_moves, nocompile_option_not_t, nocompile_struct_string_slices, pattern_matching_ownership, struct_field_borrowing, structure, tuple_structure, unit_structure

Projekat je proveren na Rust 1.75.0 i na najnovijoj stabilnoj verziji.
